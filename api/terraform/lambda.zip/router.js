const express = require('express');
const bodyParser = require('body-parser');
const passport = require('passport');
const strategy = require('passport-custom').Strategy;
const jwt = require('jsonwebtoken');
const config = require('./config');
const https = require('https');
const cors = require('cors');
const User = require('./models/user');

const router = express.Router();
// strips the /flashcards route set up for the target group
const stripServer = (req, res, next) => {
  req.url = req.originalUrl.replace('/beanieboos', '');
  next();
}
const authenticationFailure = 'authentication failure'

const strat = new strategy(
  (req, done) => {
    config.getPublicKey()
    .then((publicKey) => {
      const options = {
        algorithm: 'RS256'
      };
      const ok = jwt.verify(req.headers.token, publicKey, options, (err, res) => {
        if (err) {
          return done(authenticationFailure, null);
        }
        return done(null, res);
      });
    });
  }
);


passport.use('authStrategy', strat);
router.use(cors())
router.use(passport.initialize());
router.use(passport.session());
router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());
router.use(stripServer);

const auth = passport.authenticate('authStrategy', { session: false });

const errHandler = (err, req, res, next) => {
  console.log(err)
  res.status(500).json({error: err.toString()});
}

router.get('/authStatus', auth, errHandler, (req, res, next) => res.send('hey there, world'));

router.post('/login', async (req, res, next) => {
  const user = new User(req.body.username, req.body.password);
  try {
    await user.login();
  } catch(err) {
    next(err);
    return;
  }

  if (user.password !== req.body.password) {
    res.status(400).send('wrong password');
    return;
  }
  user.password = null;
  config.getPrivateKey()
  .then(async(privateKey) => {
    const options = {
      algorithm: 'RS256'
    };
    const token = await jwt.sign(JSON.stringify(user), privateKey, options);
    const loginResp = {
      token: token,
      username: user.username,
      settings: user.settings
    }
    res.json(loginResp);
  }).catch((err) => {
    res.error('error getting private key: ', err)
  })
});

router.get('/user/:username', auth, async (req, res, next) => {
  const user = new User(req.params.username)
  try {
    res.json(await user.get());
  } catch(err) {
    next(err);
  }
});

router.post('/user', async (req, res, next) => {
  const user = new User(req.body.username, req.body.password);
  user.settings = user.defaultSettings();
  try {
    res.json(await user.create());
  } catch (err) {
    next(err);
  }
});

router.put('/user/:username/settings', auth, async (req, res, next) => {
  const user = new User(req.params.username);
  user.settings = req.body.settings;
  try {
    res.json(await user.updateSettings());
  } catch (err) {
    console.log(err)
    next(err);
  }
});

router.get('*', (req, res) => {
  console.log('req', req.originalUrl)
  res.send('I catch everything')
});

router.use(errHandler);

router.use(cors());
