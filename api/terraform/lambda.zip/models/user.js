const AWS = require('aws-sdk');
const config = require('../config');
const crypto = require('crypto');
const converter = AWS.DynamoDB.Converter;

const region = 'us-west-1';
const tableName = 'beaniebooUsers';

AWS.config.update({region: region});
if (process.env.NODE_ENV === 'local') {
  AWS.config.credentials = new AWS.SharedIniFileCredentials({profile: 'jds'});
}

const ddb = new AWS.DynamoDB();

module.exports = class User {
  constructor(username, password) {
    this.username = username;
    this.password = password;
  }

  async login() {
    const key = await config.getPrivateKey()
    const params = {
      TableName: tableName,
      Key: {
        'username': {S: this.username}
      },
      ProjectionExpression: 'username,password,beanieboos'
    }
    return new Promise((res, rej) => {
      ddb.getItem(params, async(err, data) => {
        if (err) {
          rej(err);
        }
        if (!data) {
          rej('data is null');
          return;
        }
        try {
          const u = AWS.DynamoDB.Converter.unmarshall(data.Item);
          const buf = new Buffer(u.password);
          const dec = crypto.privateDecrypt(key.toString(), buf)
          if (this.password = dec.toString()) {
            res(this)
          }
          rej('authentication error');
        } catch (err) {
          rej(err);
        }
      });
    });
  }

  async get() {
    const params = {
      TableName: tableName,
      Key: {
        'username': {S: this.username}
      },
      ProjectionExpression: 'username,beanieboos'
    }
    return new Promise((res, rej) => {
      ddb.getItem(params, async(err, data) => {
        if (err) {
          rej(err);
        }
        if (!data) {
          rej('data is null');
          return;
        }
        try {
          const u = AWS.DynamoDB.Converter.unmarshall(data.Item)
          res(u);
        } catch (err) {
          rej(err);
        }
      });
    });
  }

  async create() {
    const buffer = Buffer.from(this.password);
    const key = await config.getPublicKey()
    var encPassword = crypto.publicEncrypt(key.toString(), buffer);
    const params = {
      TableName: tableName,
      Item: {
        'username': { S: this.username },
        'password': { B: encPassword },
        'beanieboos': converter.input(this.beanieboos, {convertEmptyValues: true})
      },
      ConditionExpression: 'attribute_not_exists(username)'
    }

    return new Promise((res, rej) => {
      ddb.putItem(params, (err, data) => {
        if (err) {
          rej(err);
          return;
        }
        res(AWS.DynamoDB.Converter.unmarshall(data.Item));
      });
    });
  }

  // updateSettings() {
  //   const params = {
  //     TableName: tableName,
  //     Key: {
  //       'username': { S: this.username }
  //     },
  //     ExpressionAttributeNames: {
  //       '#settings': 'settings'
  //     },
  //     ExpressionAttributeValues: {
  //       ':settings': {
  //         S: JSON.stringify(this.settings)
  //       }
  //     },
  //     UpdateExpression: 'set #settings = :settings',
  //     ConditionExpression: 'attribute_exists(username)',
  //     ReturnValues: 'ALL_NEW'
  //   }
  //   return new Promise((res, rej) => {
  //     ddb.updateItem(params, (err, data) => {
  //       if (err) {
  //         rej(err);
  //         return;
  //       }
  //       const u = AWS.DynamoDB.Converter.unmarshall(data.Attributes);
  //       u.settings = u.settings ? JSON.parse(u.settings) : null;
  //       u.password = null;
  //       res(u);
  //     });
  //   });
  // }

  delete() {
    const params = {
      TableName: tableName,
      Key: {
        'username': { S: this.username }
      }
    }
    return new Promise((res, rej) => {
      ddb.deleteItem(params, (err, data) => {
        if (err) {
          rej(err);
          return;
        }
        res(AWS.DynamoDB.Converter.unmarshall(data.Item));
      })
    })
  }

  hello() {
    console.log('hello ', this.username);
  }
};
