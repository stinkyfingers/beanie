var expect  = require('chai').expect;
var User = require('./beanie');


describe.only('Beanie', () => {
  const beanie = new Beanie('bobby')

  it('creates', async() => {
    const b = await beanie.create();
    // expect(b).to.deep.equal({});
  });

  it('gets', async() => {
    const b = await beanie.get();
    console.log(b)
    // expect(u.username).to.equal('bobby');
    // expect(u.password).to.be.undefined;
  });

  // it('deletes', async() => {
  //   const u = await user.delete();
  //   expect(u).to.deep.equal({});
  // });
});
