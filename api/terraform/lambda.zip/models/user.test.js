var expect  = require('chai').expect;
var User = require('./user');


describe('User', () => {
  const user = new User('bobby');
  user.password = 'test';

  it('creates', async() => {
    user.beanieboos = [{name: 'testboo'}];
    const u = await user.create();
    expect(u).to.deep.equal({});
  });

  // it('updates', async() => {
  //   const u = await user.updateSettings();
  //   expect(u).to.deep.equal({username: 'bobby', password: null);
  // });

  it('logins', async() => {
    const u = await user.login();
    expect(u).to.deep.equal({username: 'bobby', password: 'test', beanieboos: [{name: 'testboo'}]});
  });

  it('gets', async() => {
    const u = await user.get();
    expect(u.username).to.equal('bobby');
    expect(u.password).to.be.undefined;
  });

  it('deletes', async() => {
    const u = await user.delete();
    expect(u).to.deep.equal({});
  });
});
